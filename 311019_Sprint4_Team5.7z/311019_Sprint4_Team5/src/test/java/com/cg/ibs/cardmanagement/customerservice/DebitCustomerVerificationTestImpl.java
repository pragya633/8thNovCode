package com.cg.ibs.cardmanagement.customerservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigInteger;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.DebitCustomer;
import com.cg.ibs.cardmanagement.service.DebitCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerification;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerificationImpl;

class DebitCustomerVerificationTestImpl {


	

	 DebitCustomer debitCustomer= new DebitCustomerClassImpl();
	    DebitCustomerVerification debitVerify = new DebitCustomerVerificationImpl();

	 

	    @Test
	    void verifyNonExistingDebitCardNumber() {
	        BigInteger debitCardNumber = new BigInteger("5456767717123456");
	        Assertions.assertThrows(IBSException.class, () -> {
	            debitVerify.verifyDebitCardNumber(debitCardNumber);
	        });
	    }

	 

	    @Test
	    void verifyExistingDebitCardNumber() {
	        BigInteger debitCardNumber = new BigInteger("5234567891012131");
	        try {
	            assertEquals(true, debitVerify.verifyDebitCardNumber(debitCardNumber));
	        } catch (IBSException e) {
	            fail(e.getMessage());
	        }

	 

	    }

	 

	    @Test
	    void verifyNonExistingAccountNumber() {
	        BigInteger accountNumber = new BigInteger("5234567891012131");
	        Assertions.assertThrows(IBSException.class, () -> {
	            debitVerify.verifyAccountNumber(accountNumber);
	        });
	    }

	 

	    @Test
	    void verifyExistngAccountNumber() {
	        BigInteger accountNumber = new BigInteger("12345678910");
	        try {
	            assertEquals(true, debitVerify.verifyAccountNumber(accountNumber));
	        } catch (IBSException e) {
	            fail("Test failed : " + e.getMessage());
	        }

	 

	    }
	    
	    @Test
	    void verifyExistingDebitPin() {
	        BigInteger debitCardNumber = new BigInteger("5234567891012131");
	        String pin="2131";
	        try {
	        assertEquals(false, debitVerify.verifyDebitPin(pin, debitCardNumber));
	        }
	        catch(IBSException e){
	            fail(e.getMessage());
	        }
	    }
	        
	        @Test
	        void verifyNonExistingDebitPin() {
	            BigInteger debitCardNumber = new BigInteger("5234567891012132");
	            String pin="2138";
	            Assertions.assertThrows(IBSException.class, () -> {
	                debitVerify.verifyDebitPin(pin, debitCardNumber);
	            });
	            
	    }
	        @Test
	        void verifyDebitCardTransactionId() {
	            BigInteger transactionId = new BigInteger("1234567892");
	            try {
	                assertEquals(true, debitVerify.checkDebitTransactionId(transactionId));    
	            }
	            catch(IBSException e){
	                fail(e.getMessage());
	            }
	            
	        }
	        @Test
	        void verifyDebitCardNonExistingTransactionId() {
	            BigInteger transactionId = new BigInteger("1236547898");
	            Assertions.assertThrows(IBSException.class, () -> {
	                debitVerify.checkDebitTransactionId(transactionId);
	            });        
	            
	        }
	        @Test
	        void verifyDebitCardStatus() {
	            BigInteger debitCardNumber = new BigInteger("5234567891012131");
	            try {
	                assertNotNull(debitVerify.getDebitCardStatus(debitCardNumber));    
	            }
	            catch(IBSException e){
	                fail(e.getMessage());
	            }
	            
	        }
	        @Test
	        void verifyNonExistingDebitCardStatus() {
	            BigInteger debitCardNumber = new BigInteger("5189101213259891");
	            Assertions.assertThrows(IBSException.class, () -> {
	                debitVerify.getDebitCardStatus(debitCardNumber);
	            });        
	            
	        }
		}

