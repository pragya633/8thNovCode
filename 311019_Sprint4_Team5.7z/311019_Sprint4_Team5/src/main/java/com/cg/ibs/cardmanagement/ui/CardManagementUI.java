package com.cg.ibs.cardmanagement.ui;

import java.math.BigInteger;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.BankService;
import com.cg.ibs.cardmanagement.service.BankServiceImpl;
import com.cg.ibs.cardmanagement.service.CreditCustomer;
import com.cg.ibs.cardmanagement.service.CreditCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerification;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerificationImpl;
import com.cg.ibs.cardmanagement.service.CustomerService;
import com.cg.ibs.cardmanagement.service.CustomerServiceImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomer;
import com.cg.ibs.cardmanagement.service.DebitCustomerClassImpl;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerification;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerificationImpl;

public class CardManagementUI {

	//static BigInteger accountNumber = null;
	static Scanner scan;
	static BigInteger debitCardNumber = null;
	static BigInteger creditCardNumber = null;
	static int userInput = -1;
	static int userInputCust = -1;
	static int ordinal = -1;
	static String pin = null;
	static String type = null;
	static BigInteger transactionId;
	static boolean success = false;
	static int myChoice = -1;

	boolean check = false;
	static String customerReferenceId = null;
	static int newCardType = -1;
	static int days = 0;
	CreditCustomerVerification creditVerify = new CreditCustomerVerificationImpl();
	CreditCustomer creditCustomer = new CreditCustomerClassImpl();
	CustomerService customerService = new CustomerServiceImpl();
	DebitCustomer debitCustomer = new DebitCustomerClassImpl();
	DebitCustomerVerification debitVerify = new DebitCustomerVerificationImpl();
	BankService bankService = new BankServiceImpl();

	public void doIt() {
		while (true) {
			success = false;
			System.out.println("Welcome to card management System");
			System.out.println("Enter 1 to login as a customer");
			System.out.println("Enter 2 to login as a bank admin");

			while (!success) {

				try {

					userInput = scan.nextInt();
					success = true;
				} catch (InputMismatchException wrongFormat) {
					scan.next();
					System.out.println("Enter between 1 or 2");

				}
			}

			if (userInput == 1) {
				success = false;
				System.out.println("You are logged in as a customer.....");
				System.out.println("....................................");
				System.out.println("Enter 1 for Debit Card Operations....");
				System.out.println("Enter 2 for Credit Card Operations....");
				while (!success) {
					try {

						userInputCust = scan.nextInt();
						success = true;
					} catch (InputMismatchException wrongFormat) {
						scan.next();
						System.out.println("Enter between 1 or 2");

					}
				}
				if (userInputCust == 1) {
					CustomerDebit ccchoice = null;
					while (ccchoice != CustomerDebit.CUSTOMER_LOG_OUT) {

						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						System.out.println("Press x to exit");
						for (CustomerDebit mmenu : CustomerDebit.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {

							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Choose a valid option");
							} catch (ArrayIndexOutOfBoundsException b) {
								System.out.println(" Choose  1/2/3/4/5/6/7/8/9");
								scan.next();

							}
						}
						if (ordinal >= 1 && ordinal <= 10) {
							ccchoice = CustomerDebit.values()[ordinal - 1];

							switch (ccchoice) {

							case LIST_EXISTING_DEBIT_CARDS:

								listExistingDebitCards();
								break;

							case APPLY_NEW_DEBIT_CARD:
								applyNewDebitCard();
								break;

							case UPGRADE_EXISTING_DEBIT_CARD:

								upgradeExistingDebitCard();
								break;

							case RESET_DEBIT_CARD_PIN:
								resetDebitCardPin();

								break;

							case REPORT_DEBIT_CARD_LOST:

								reportDebitCardLost();

								break;

							case REQUEST_DEBIT_CARD_STATEMENT:
								requestDebitCardStatement();

								break;

							case REPORT_DEBITCARD_STATEMENT_MISMATCH:

								reportDebitStatementMismatch();
								break;

							case CUSTOMER_LOG_OUT:
								System.out.println("LOGGED OUT");
								break;
							case VIEW_REQUEST_STATUS:
								viewQueryStatus();

								break;
							}
						}
					}
				} else if (userInputCust == 2) {

					CustomerCredit chhoice = null;
					while (chhoice != CustomerCredit.CUSTOMER_LOG_OUT) {

						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						System.out.println("Press x to exit");
						for (CustomerCredit mmenu : CustomerCredit.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {

							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Choose a valid option");
							} catch (ArrayIndexOutOfBoundsException b) {
								scan.next();
								System.out.println(" Choose  1/2/3/4/5/6/7/8/9");
							}
						}
						if (ordinal >= 1 && ordinal <= 10) {
							chhoice = CustomerCredit.values()[ordinal - 1];

							switch (chhoice) {

							case LIST_EXISTING_CREDIT_CARDS:

								listExistingCreditCards();
								break;
							case APPLY_NEW_CREDIT_CARD:
								applyNewCreditCard();
								break;
							case UPGRADE_EXISTING_CREDIT_CARD:
								upgradeExistingCreditCard();
								break;
							case RESET_CREDIT_CARD_PIN:
								resetCreditCardPin();
								break;
							case REPORT_CREDIT_CARD_LOST:
								reportCreditCardLost();
								break;
							case REQUEST_CREDIT_CARD_STATEMENT:
								requestCreditCardStatement();
								break;
							case REPORT_CREDITCARD_STATEMENT_MISMATCH:
								reportCreditStatementMismatch();
								break;
							case CUSTOMER_LOG_OUT:
								System.out.println("LOGGED OUT");
								break;
							case VIEW_REQUEST_STATUS:
								viewQueryStatus();
							}
						}

					}
				}
			} else {
				if (userInput == 2) {

					System.out.println("You are logged in as a Bank Admin");
					BankMenu cchoice = null;
					while (cchoice != BankMenu.BANK_LOG_OUT) {
						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						for (BankMenu mmenu : BankMenu.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {
							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Enter a valid  option");
							} catch (ArrayIndexOutOfBoundsException b) {
								scan.next();
								System.out.println(" Choose  1/2/3/4/5");
							}
						}

						if (ordinal >= 1 && ordinal <= 6) {
							cchoice = BankMenu.values()[ordinal - 1];

							switch (cchoice) {

							case LIST_QUERIES:

								listPendingQueries();
								break;

							case REPLY_QUERIES:
								replyQueries();
								break;
							case VIEW_DEBIT_CARD_STATEMENT:
								viewBankDebitCardStatement();

								break;
							case VIEW_CREDIT_CARD_STATEMENT:
								viewBankCreditCardStatement();
								break;
							case BANK_LOG_OUT:
								System.out.println("LOGGED OUT");
								break;

							}
						}
					}
				} else {
					System.out.println("Invalid Option!!");

				}

			}

		}
	}

	void listExistingDebitCards() {
		List<DebitCardBean> debitCardBeans;
		try {
			debitCardBeans = debitCustomer.viewAllDebitCards();

			if (debitCardBeans.isEmpty()) {
				System.out.println("No Existing Debit Cards");
			} else {

				for (DebitCardBean debitCardBean : debitCardBeans) {

					System.out.println("Debit Card Number             :\t" + debitCardBean.getCardNumber());
					System.out.println("Type                          :\t" + debitCardBean.getCardType());

					System.out.println("Name                          :\t" + debitCardBean.getNameOnCard());
					System.out.println("Status                        :\t  " + debitCardBean.getCardStatus());
					System.out.println("Date of expiry(yyyy/MM/dd)    :\t" + debitCardBean.getDateOfExpiry());
				    //System.out.println(debitCardBean.getAccountBeanObject().getAccountNumber());
					System.out.println("......................................................");
				}
			}
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	void listExistingCreditCards() {

		List<CreditCardBean> creditCardBeans;
		try {
			creditCardBeans = creditCustomer.viewAllCreditCards();

			if (creditCardBeans.isEmpty()) {
				System.out.println("No Existing Credit Cards");
			} else {
				for (CreditCardBean creditCardBean : creditCardBeans) {

					System.out.println("Credit Card Number                    :\t" + creditCardBean.getCardNumber());
					System.out.println("Credit Card Status                    :\t" + creditCardBean.getCardStatus());
					System.out.println("Name on Credit card                   :\t" + creditCardBean.getNameOnCard());
					System.out.println("Date of expiry(yyyy/MM/dd)            :\t" + creditCardBean.getDateOfExpiry());
					System.out.println("Credit card type                      :\t" + creditCardBean.getCardType());

					System.out.println("......................................................");
				}
			}
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	void applyNewDebitCard() {
		BigInteger accountNumber=null;
		try {
		check=debitCustomer.checkDebitCardCount();}
		catch (IBSException e) {
			System.out.println(e.getMessage());
		}
		
		
		if(check) {
        int accountChoice=-1;
		success = false;
		System.out.println("You are applying for a new Debit Card");
		System.out.println("To exit, press x");
		while (!success) {

			try {
				
				
				
			List<AccountBean> accounts=debitCustomer.getAccountList();
			int count=1;
			for (AccountBean account: accounts ) {
				System.out.println("Sr No                         :\t" + count++);
				System.out.println("Account Number                :\t" + account.getAccountNumber());
				

				System.out.println(".......................................................");
			}
				System.out.println("Choose Account Number you want to apply debit card for :");

				accountChoice = scan.nextInt();
				accountNumber=accounts.get(accountChoice- 1).getAccountNumber();
                 System.out.println(accountNumber);
				success = true;
			} catch (InputMismatchException wrongFormat) {

				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IBSException notFound) {
				System.out.println(notFound.getMessage());

			}
		}
		
			success = false;
			while (!success) {

				try {
					System.out.println("We offer three kinds of Debit Cards:");
					System.out.println(".....................................");
					System.out.println("1 for  Platinum");
					System.out.println("2 for  Gold");
					System.out.println("3 for Silver");
					System.out.println("Choose between 1 to 3");

					newCardType = scan.nextInt();

					System.out.println("You have applied for: " + customerService.getNewCardtype(newCardType));
					System.out.println(accountNumber);
					customerReferenceId = debitCustomer.applyNewDebitCard(accountNumber,
							customerService.getNewCardtype(newCardType));
					System.out.println("Application for new debit card success!!");
					System.out.println("Your reference Id is " + customerReferenceId);
					success = true;

				} catch (InputMismatchException cardNew) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2/3");

				} catch (IBSException cardNew) {
					System.out.println(cardNew.getMessage());

				}

			}}
		else {
			System.out.println("You already have 3 Active cards on this account");
		}
		
	}

	void applyNewCreditCard() {
		BigInteger uci = null;
		success = false;
		System.out.println("You are applying for a new Credit Card");
		System.out.println("To exit, press x");
		while (!success) {
			try {

				System.out.println("Enter your uci");
				uci = scan.nextBigInteger();
				check = customerService.verifyUci(uci);
				success = true;
			} catch (InputMismatchException wrongFormat) {

				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Renter valid uci");

			} catch (IBSException notFound) {
				System.out.println(notFound.getMessage());
			}
		}
		if (check) {
			success = false;
			while (!success) {

				try {

					System.out.println("We offer three kinds of Credit Cards:");
					System.out.println(".....................................");
					System.out.println("1 for  Platinum");
					System.out.println("2 for  Gold");
					System.out.println("3 for Silver");
					System.out.println("Choose between 1 to 3");

					newCardType = scan.nextInt();

					System.out.println("You have applied for: " + customerService.getNewCardtype(newCardType));
					customerReferenceId = creditCustomer.applyNewCreditCard(customerService.getNewCardtype(newCardType),
							uci);
					System.out.println("Application for new Credit card success!!");

					System.out.println("Your reference Id is " + customerReferenceId);
					success = true;

				} catch (InputMismatchException cardNew) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2/3");

				} catch (IBSException cardNew) {
					System.out.println(cardNew.getMessage());

				}

			}
		}
	}

	void upgradeExistingDebitCard() {
		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::");

		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			int index = 1;
			for (DebitCardBean debitCardBean : unblockedCards) {
				System.out.println("Sr no.                        :\t" + index++);
				System.out.println("Debit Card Number             :\t" + debitCardBean.getCardNumber());
				System.out.println("Type                          :\t" + debitCardBean.getCardType());

				System.out.println("Name                          :\t" + debitCardBean.getNameOnCard());
				System.out.println("Status                        :\t  " + debitCardBean.getCardStatus());
				System.out.println("Date of expiry(yyyy/MM/dd)    :\t" + debitCardBean.getDateOfExpiry());
				System.out.println("......................................................");
			}
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;
		String mString = null;
		System.out.println(" Choose Debit Card you want to upgrade.................. ");
		System.out.println("To exit, press x");
		while (!success) {

			try {

				debitCardChoice = scan.nextInt();
				// check = debitVerify.verifyDebitCardNumber(debitCardNumber);
				 debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				System.out.println(debitCardNumber);
				type = debitCustomer.getDebitcardType(debitCardNumber);
				System.out.println(type);
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IBSException noCard) {
				System.out.println(noCard.getMessage());

			}
		}

	
			if (type.equalsIgnoreCase("Silver")) {
				System.out.println("Choose 1 to upgrade to Gold");
				System.out.println("Choose 2 to upgrade to Platinum");

				success = false;
				while (!success) {
					try {
						myChoice = scan.nextInt();
						mString = customerService.checkMyChoice(myChoice);
						System.out.println("You have applied for " + mString);

						success = true;
					} catch (InputMismatchException wrongFormat) {
						if (scan.next().equalsIgnoreCase("x"))
							return;
						System.out.println("Choose between 1 or 2");

					} catch (IBSException e) {
						System.out.println(e.getMessage());
					}
				}
				try {
					System.out.println("Ticket Raised successfully . Your reference Id is "
							+ debitCustomer.requestDebitCardUpgrade(debitCardNumber, mString));
				} catch (IBSException e) {
					System.out.println(e.getMessage());
				}
			} else if (type.equalsIgnoreCase("Gold")) {
				System.out.println("Choose 2 to upgrade to Platinum");
				success = false;

				while (!success) {
					try {
						myChoice = scan.nextInt();
						mString = customerService.checkMyChoiceGold(myChoice);
						System.out.println("You have chosen " + mString);
						success = true;

					} catch (InputMismatchException wrongFormat) {
						if (scan.next().equalsIgnoreCase("x"))
							return;
						System.out.println("Enter 2 to upgrade");

					} catch (IBSException e) {
						System.out.println(e.getMessage());
					}
				}
				try {
					System.out.println("Ticket Raised successfully . Your reference Id is "
							+ debitCustomer.requestDebitCardUpgrade(debitCardNumber, mString));
				} catch (IBSException e) {
					System.out.println(e.getMessage());
				}

			} else {
				System.out.println("You already have a Platinum Card");
			}

		}

	

	void upgradeExistingCreditCard() {
		System.out.println("Your existing credit cards are :::");
		listExistingCreditCards();
		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println("Enter your Credit Card Number: ");
		while (!success) {

			try {

				creditCardNumber = scan.nextBigInteger();
				check = creditVerify.verifyCreditCardNumber(creditCardNumber);
				type = creditVerify.verifyCreditcardType(creditCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Enter a valid Credit card number");

			} catch (NullPointerException notFound) {
				System.out.println(notFound.getMessage());

			} catch (IBSException notFound) {
				System.out.println(notFound.getMessage());

			}
			try {
				if (creditVerify.getCreditCardStatus(creditCardNumber)) {
					if (check) {

						if (type.equalsIgnoreCase("Silver")) {
							System.out.println("Choose 1 to upgrade to Gold");
							System.out.println("Choose 2 to upgrade to Platinum");

							success = false;
							while (!success) {
								try {
									myChoice = scan.nextInt();

									success = true;
								} catch (InputMismatchException wrongFormat) {
									if (scan.next().equalsIgnoreCase("x"))
										return;
									System.out.println("Choose between 1 or 2");

								}
							}
							try {
								System.out.println("Ticket Raised successfully . Your reference Id is "
										+ creditCustomer.requestCreditCardUpgrade(creditCardNumber, myChoice));
							} catch (IBSException e) {
								System.out.println(e.getMessage());
							}
						} else if (type.equalsIgnoreCase("Gold")) {
							System.out.println("Choose 2 to upgrade to Platinum");
							success = false;

							while (!success) {
								try {
									myChoice = scan.nextInt();
									System.out.println(customerService.checkMyChoiceGold(myChoice));
									success = true;

								} catch (InputMismatchException wrongFormat) {
									if (scan.next().equalsIgnoreCase("x"))
										return;
									System.out.println("Enter 2 to upgrade");

								} catch (IBSException e) {
									System.out.println(e.getMessage());
								}
							}
							try {
								System.out.println("Ticket Raised successfully . Your reference Id is "
										+ creditCustomer.requestCreditCardUpgrade(creditCardNumber, myChoice));
							} catch (IBSException e) {
								System.out.println(e.getMessage());
							}

						} else {
							System.out.println("You already have a Platinum Card");
						}

					}
				} else {
					System.out.println("YOUR CARD IS BLOCKED");
				}
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	void resetDebitCardPin() {
		System.out.println("Your existing Debit cards are:::");
		System.out.println("................................");
		listExistingDebitCards();
		System.out.println("................................");
		success = false;
		System.out.println("Enter your Debit Card Number: ");

		System.out.println("To exit, press x");

		while (!success) {

			try {
				debitCardNumber = scan.nextBigInteger();

				check = debitVerify.verifyDebitCardNumber(debitCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Enter a valid debit card number");
			} catch (IBSException newException) {
				System.out.println(newException.getMessage());
			}

		}
		
			
				if (check) {
					System.out.println("Enter your existing pin:");

					success = false;
					while (!success) {
						try {

							pin = scan.next();

							if (customerService.getPinLength(pin) == 4) {

								if (debitVerify.verifyDebitPin(pin, debitCardNumber)) {
									System.out.println("Enter new pin");
									success = false;
									while (!success) {
										try {

											pin = scan.next();

											if (customerService.getPinLength(pin) != 4)
												throw new IBSException("Incorrect Length of pin ");

											else {

												System.out.println("Re-enter your new pin");
												String rpin = scan.next();
												if (customerService.getPinLength(rpin) != 4)
													throw new IBSException("Incorrect Length of pin ");
												else {
													if (rpin.equals(pin)) {
														debitCustomer.resetDebitPin(debitCardNumber, pin);
														System.out.println("PIN CHANGED SUCCESSFULLY!!!");
														success = true;
													} else {
														System.out.println("PINS DO NOT MATCH...TRY AGAIN");
														success = true;
													}
												}
											}

										} catch (InputMismatchException wrongFormat) {
											System.out.println("Enter a valid 4 digit pin");
											scan.next();

										} catch (IBSException ExceptionObj) {
											System.out.println(ExceptionObj.getMessage());

										}
									}

								} else {

									System.out.println("You have entered wrong pin ");
									System.out.println("Try again");
								}
							}
							success = true;
						} catch (InputMismatchException wrongFormat) {
							System.out.println("Enter a valid 4 digit pin");
							scan.next();

						} catch (IBSException ExceptionObj) {
							System.out.println(ExceptionObj.getMessage());

						}
					}
				}
			
	}

	void resetCreditCardPin() {
		System.out.println("Your existing credit cards are :::");
		System.out.println("................................");
		listExistingCreditCards();
		System.out.println("................................");
		success = false;
		System.out.println("To exit, press x");
		System.out.println("Enter your Credit Card Number: ");
		while (!success) {
			try {
				creditCardNumber = scan.nextBigInteger();
				check = creditVerify.verifyCreditCardNumber(creditCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Enter a valid credit card number");
			} catch (IBSException newException) {
				System.out.println(newException.getMessage());
			}
		}

		try {
			if (creditVerify.getCreditCardStatus(creditCardNumber)) {

				if (check) {
					System.out.println("Enter your existing pin:");
					success = false;
					while (!success) {
						try {

							String pin = scan.next();

							if (customerService.getPinLength(pin) == 4)

								if (creditVerify.verifyCreditPin(pin, creditCardNumber)) {
									System.out.println("Enter new pin");
									success = false;
									while (!success) {
										try {

											pin = scan.next();

											if (customerService.getPinLength(pin) != 4)
												throw new IBSException("Incorrect Length of pin ");

											else {

												System.out.println("Re-enter your new pin");
												String rpin = scan.next();
												if (customerService.getPinLength(rpin) != 4)
													throw new IBSException("Incorrect Length of pin ");
												else {
													if (rpin.equals(pin)) {
														creditCustomer.resetCreditPin(creditCardNumber, pin);
														System.out.println("PIN CHANGED SUCCESSFULLY!!!");
														success = true;
													} else {
														System.out.println("PINS DO NOT MATCH...TRY AGAIN");
														success = true;
													}
												}
											}

										} catch (InputMismatchException wrongFormat) {
											System.out.println("Enter a valid 4 digit pin");
											if (scan.next().equalsIgnoreCase("x"))
												return;

										} catch (IBSException ExceptionObj) {
											System.out.println(ExceptionObj.getMessage());

										}
									}

								} else {

									System.out.println("You have entered wrong pin ");
									System.out.println("Try again");
								}
							success = true;
						} catch (InputMismatchException wrongFormat) {
							System.out.println("Enter a valid 4 digit pin");
							if (scan.next().equalsIgnoreCase("x"))
								return;

						} catch (IBSException ExceptionObj) {
							System.out.println(ExceptionObj.getMessage());

						}
					}
				}
			} else {
				System.out.println("YOUR CARD IS BLOCKED");
			}
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

	}

	void reportDebitCardLost() {
		System.out.println("Your existing Debit cards are:::");
		System.out.println("................................");
		listExistingDebitCards();
		System.out.println("................................");
		success = false;
		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your Debit Card Number: ");
				debitCardNumber = scan.nextBigInteger();
				check = debitVerify.verifyDebitCardNumber(debitCardNumber);
				if (check) {
//					System.out.println("Ticket Raised successfully . Your reference Id is "
//							+ debitCustomer.requestDebitCardLost(debitCardNumber));
					debitCustomer.requestDebitCardLost(debitCardNumber);
					System.out.println("Your card has been BLOCKED. Contact branch for further process.");
					success = true;
				}
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");

			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}

		}
	}

	void reportCreditCardLost() {
		System.out.println("Your existing credit cards are :::");
		System.out.println("................................");
		listExistingCreditCards();
		System.out.println("................................");
		success = false;
		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your Credit Card Number: ");
				creditCardNumber = scan.nextBigInteger();
				check = creditVerify.verifyCreditCardNumber(creditCardNumber);
				if (check) {
//					System.out.println("Ticket Raised successfully . Your reference Id is "
//							+ creditCustomer.requestCreditCardLost(creditCardNumber));
					creditCustomer.requestCreditCardLost(creditCardNumber);
					System.out.println("Your card has been BLOCKED. Contact branch for further process.");
					success = true;
				}

			} catch (InputMismatchException wrongFormat) {

				System.out.println("Not a valid format");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
	}

	void requestDebitCardStatement() {
		System.out.println("Your existing Debit cards are:::");
		System.out.println("................................");
		listExistingDebitCards();
		System.out.println("................................");
		success = false;

		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your Debit Card Number: ");
				debitCardNumber = scan.nextBigInteger();
				check = debitVerify.verifyDebitCardNumber(debitCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");
			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
		success = false;

		if (check) {
			while (!success) {
				try {
					System.out.println("enter days : ");
					days = scan.nextInt();
					customerService.checkDays(days);
					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Not a valid format");
				} catch (IBSException newException) {
					System.out.println(newException.getMessage());

				}
			}

			try {
				List<DebitCardTransaction> debitCardBeanTrns = debitCustomer.getDebitTransactions(days,
						debitCardNumber);

				for (DebitCardTransaction debitCardTrns : debitCardBeanTrns) {
					System.out.println("Transaction ID                 :\t" + debitCardTrns.getTransactionId());
					System.out.println("UCI                            :\t" + debitCardTrns.getUCI());

					// System.out.println("Debit card number :\t" +
					// debitCardTrns.getDebitCardNumber());
					System.out.println("Date of transaction(yyyy/MM/dd):\t" + debitCardTrns.getTransactionDate());
					System.out.println("Amount                         :\t" + debitCardTrns.getTransactionAmount());
					System.out
							.println("Description                    :\t" + debitCardTrns.getTransactionDescription());
					System.out.println(".......................................................");
				}
			}

			catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
	}

	void requestCreditCardStatement() {
		System.out.println("Your existing credit cards are :::");
		System.out.println("................................");
		listExistingCreditCards();
		System.out.println("................................");
		success = false;

		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your Credit Card Number: ");
				creditCardNumber = scan.nextBigInteger();
				check = creditVerify.verifyCreditCardNumber(creditCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");

			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
		success = false;

		if (check) {
			while (!success) {
				try {
					System.out.println("enter days : ");
					days = scan.nextInt();
					customerService.checkDays(days);
					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Not a valid format");

				} catch (IBSException e) {

					System.out.println(e.getMessage());

				}
			}

			try {
				List<CreditCardTransaction> creditCardBeanTrns = creditCustomer.getCreditTrans(days, creditCardNumber);
				for (CreditCardTransaction creditCardTrns : creditCardBeanTrns) {
					System.out.println("Transaction ID                 :\t" + creditCardTrns.getTransactionId());
					System.out.println("UCI                            :\t" + creditCardTrns.getUCI());
					// System.out.println("Credit card number :\t" +
					// creditCardTrns.getCreditCardNumber());
					System.out.println("Date of transaction(yyyy/MM/dd):\t" + creditCardTrns.getDateOfTran());
					System.out.println("Amount                         :\t" + creditCardTrns.getAmount());
					System.out.println("Description                    :\t" + creditCardTrns.getDescription());
					System.out.println(".......................................................");

				}

			}

			catch (IBSException e) {

				System.out.println(e.getMessage());

			}
		}

	}

	void reportDebitStatementMismatch() {

		success = false;
		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your transaction id");

				transactionId = scan.nextBigInteger();
				check = debitVerify.checkDebitTransactionId(transactionId);
				if (check) {
					System.out.println("Enter details regarding the mismatch:");
					String remarks=scan.next();
					
					System.out.println("Ticket Raised successfully . Your reference Id is "
							+ debitCustomer.raiseDebitMismatchTicket(transactionId,remarks));

					success = true;
				}
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;

				System.out.println("Not a valid format");

			} catch (IBSException e) {

				System.out.println(e.getMessage());

			}
		}
	}

	void reportCreditStatementMismatch() {
		success = false;
		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your transaction id");
				transactionId = scan.nextBigInteger();
				check = creditVerify.verifyCreditCardTransactionId(transactionId);
				if (check) {
					System.out.println("Ticket Raised successfully . Your reference Id is "
							+ creditCustomer.raiseCreditMismatchTicket(transactionId));
					success = true;
				}
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;

				System.out.println("Not a valid format");
			} catch (IBSException e) {
				System.out.println(e.getMessage());

			}
		}

	}

	void viewQueryStatus() {
		success = false;
		while (!success) {
			System.out.println("To exit, press x");
			System.out.println("Enter your Unique Reference ID");
			try {
				if ((customerReferenceId = scan.next()).equalsIgnoreCase("x"))
					return;

				System.out.println(customerService.viewServiceRequestStatus(customerReferenceId));
				success = true;
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			} catch (NullPointerException n) {
				System.out.println("Not Found");

			}
		}

	}

	void listPendingQueries() {

		try {
			List<CaseIdBean> caseBeans = bankService.viewQueries();
			if (caseBeans.isEmpty()) {
				System.out.println("No Existing Queries");
			} else {

				for (CaseIdBean caseId : caseBeans) {
					System.out.println("CaseId               :\t" + caseId.getCaseIdTotal());
					System.out.println("Case time stamp      :\t" + caseId.getCaseTimeStamp());
					System.out.println("Status of Query      :\t" + caseId.getStatusOfServiceRequest());
					System.out.println("Account Number       :\t" + caseId.getAccountNumber());
					System.out.println("UCI                  :\t" + caseId.getUCI());
					System.out.println("Query definition     :\t" + caseId.getDefineServiceRequest());
					System.out.println("Card Number          :\t" + caseId.getCardNumber());
					System.out.println("Customer Reference ID:\t" + caseId.getCustomerReferenceId());
					System.out.println(".......................................................");

				}
			}

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	void replyQueries() {
		String queryId = null;
		int newStatus = -1;
		success = false;
		while (!success) {
			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your case ID: ");
				if ((queryId = scan.next()).equalsIgnoreCase("x"))
					return;
				check = bankService.verifyQueryId(queryId);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				scan.next();
				System.out.println("Not a valid format");

			} catch (IBSException ibs) {
				System.out.println(ibs.getMessage());

			}
		}
		if (check) {

			success = false;
			while (!success) {
				System.out.println("Select new Status from the following list:");
				System.out.println("..........................................");
				System.out.println("1 for Approved...... ");
				System.out.println("2 for In Process.....");
				System.out.println("3 for Disapproved ...");

				String newQueryStatus;
				try {
					newStatus = scan.nextInt();
					newQueryStatus = bankService.getNewQueryStatus(newStatus);

					System.out.println(" You have chosen " + newQueryStatus);

					bankService.setQueryStatus(queryId, newQueryStatus);

					success = true;
				} catch (IBSException e) {
					System.out.println(e.getMessage());

				} catch (InputMismatchException e) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2/3");

				}

			}

		}

		else {
			System.out.println("Invalid query id");
		}
	}

	void viewBankDebitCardStatement() {
		success = false;

		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your Debit Card Number: ");
				debitCardNumber = scan.nextBigInteger();
				check = bankService.verifyDebitCardNumber(debitCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");
			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
		success = false;
		if (check) {
			while (!success) {
				try {
					System.out.println("enter days : ");
					days = scan.nextInt();
					bankService.checkDays(days);
					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Not a valid format");
				} catch (IBSException newException) {
					System.out.println(newException.getMessage());

				}
			}

			try {
				List<DebitCardTransaction> debitCardBeanTrns = bankService.getDebitTransactions(days, debitCardNumber);
				for (DebitCardTransaction debitCardTrns : debitCardBeanTrns)
					System.out.println(debitCardTrns.toString());

			}

			catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
	}

	void viewBankCreditCardStatement() {
		success = false;

		while (!success) {

			try {
				System.out.println("To exit, press x");
				System.out.println("Enter your Credit Card Number: ");
				creditCardNumber = scan.nextBigInteger();
				check = bankService.verifyCreditCardNumber(creditCardNumber);

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Not a valid format");

			} catch (IBSException newException) {
				System.out.println(newException.getMessage());

			}
		}
		success = false;
		if (check) {
			while (!success) {
				try {
					System.out.println("enter days : ");
					days = scan.nextInt();
					bankService.checkDays(days);
					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Not a valid format");

				} catch (IBSException e) {
					System.out.println(e.getMessage());

				}
			}
			try {
				List<CreditCardTransaction> creditCardBeanTrns = bankService.getCreditTrans(days, creditCardNumber);
				for (CreditCardTransaction creditCardTrns : creditCardBeanTrns)
					System.out.println(creditCardTrns.toString());

			}

			catch (IBSException e) {

				System.out.println(e.getMessage());

			}
		}
	}

	public static void main(String args[]) throws Exception {
		scan = new Scanner(System.in);
		CardManagementUI obj = new CardManagementUI();
		obj.doIt();
		System.out.println("Program End");
		scan.close();
	}
}
