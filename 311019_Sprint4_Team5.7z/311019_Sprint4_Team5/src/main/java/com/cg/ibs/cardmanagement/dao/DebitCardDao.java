package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface DebitCardDao {
	boolean verifyDebitCardNumber(BigInteger debitCardNumber) throws IBSException;

	String getDebitCardStatus(BigInteger debitCardNumber) throws IBSException;

	String getDebitCardPin(BigInteger debitCardNumber) throws IBSException;

	public void setNewDebitPin(BigInteger debitCardNumber, String newPin) throws IBSException;

	String getdebitCardType(BigInteger debitCardNumber) throws IBSException;

	List<DebitCardBean> viewAllDebitCards() throws IBSException;

	void actionUpgradeDC(String queryId) throws IBSException;

	void actionANDC(DebitCardBean bean) throws IBSException;

	BigInteger getDMAccountNumber(BigInteger debitCardNumber) throws IBSException;

	//void actionBlockDC(String queryId, String status) throws IBSException;
	BigInteger getAccountNumber(BigInteger debitCardNumber) throws IBSException;

	void blockDebitCard(BigInteger debitCardNumber) throws IBSException;

	List<DebitCardBean> viewAllUnblockedDebitCards() throws IBSException;

	List<AccountBean> getAccountList() throws IBSException;

}
