package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class DebitCardTransactionDaoImpl implements DebitCardTransactionDao {
	private static Logger logger = Logger.getLogger(DebitCardTransactionDaoImpl.class);
	private EntityManager entityManager;

	public DebitCardTransactionDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
	}

	@Override
	public boolean verifyDebitTransactionId(BigInteger transactionId) throws IBSException {
		logger.info("entered into verifyDebitTransactionId method of DebitCardTransactionDaoImpl class");
		boolean result = false;

		DebitCardTransaction d = entityManager.find(DebitCardTransaction.class, transactionId);

		if (d != null) {
			result = true;
		}

		return result;

	}

	@Override
	public List<DebitCardTransaction> getDebitTrans(int days, BigInteger debitCardNumber) throws IBSException {
		logger.info("entered into getDebitTrans method of DebitCardTransactionDaoImpl class");
		  LocalDateTime fromDate1 = LocalDateTime.now().minusDays(days); 
		  LocalDateTime currentDate1 = LocalDateTime.now();
	
		TypedQuery<DebitCardTransaction> query = entityManager.createQuery(
				"Select d from DebitCardTransaction d JOIN d.debitBeanObject c WHERE d.transactionDate BETWEEN :start and :end AND c.cardNumber=:cardNum " , DebitCardTransaction.class);
		query.setParameter("start", fromDate1);
		query.setParameter("end", currentDate1);
		query.setParameter("cardNum", debitCardNumber);
		return query.getResultList();
	}

	@Override
	public BigInteger getDMUci(BigInteger transactionID) throws IBSException {
		logger.info("entered into getDMUci method of DebitCardTransactionDaoImpl class");
BigInteger uci=null;

try {
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"Select d.UCI from DebitCardTransaction d where d.transactionId=:transactionId", BigInteger.class);
		query.setParameter("transactionId", transactionID);
uci= query.getSingleResult();}
catch (NoResultException e) {
	throw new IBSException(ErrorMessages.NO_UCI);
}
		return uci;

	}

	@Override
	public BigInteger getDebitCardNumber(BigInteger transactionID) throws IBSException {
		logger.info("entered into getDebitCardNumber method of DebitCardTransactionDaoImpl class");
		BigInteger cardNumber=null;
		try {
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"Select c.cardNumber from DebitCardTransaction d  join d.debitBeanObject c where d.transactionId=:transactionId", BigInteger.class);
		query.setParameter("transactionId", transactionID);
		
		cardNumber=query.getSingleResult();
		}catch (NoResultException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
		return cardNumber ;

	}

}
